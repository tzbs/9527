import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame//创建一个游戏窗口GameFrame类
{
    public static ChessBoard MyBoarder;//创建一个静态的棋盘对象
    public static int doplayer=0;
    public static int temp=0;

    public GameFrame() {
        MyBoarder = new ChessBoard();//为这个棋盘对象赋值
        // 设置窗口标题
        this.setTitle("中国象棋");//窗口标题
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/black-jiang.png")));
        // 设置窗口大小
        this.setSize(574, 667);//窗口大小
        this.setResizable(false);//窗口大小固定，用户无法改变

        // 设置窗口在屏幕中的位置
        this.setLocationRelativeTo(null);
        // 设置窗口关闭时的操作（退出程序）
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(null);//无布局管理器
        this.setVisible(true);//窗口可见
        ChessBoardPanel chessBoardPanel = new ChessBoardPanel();//创建一个棋盘棋盘容器对象，并初始化
        chessBoardPanel.addMouseListener(new ChessPieceClick());//为这个棋盘对象添加鼠标监听器（棋盘上的人机互动）
        this.add(chessBoardPanel);//将这个棋盘容器对象添加到窗口中
        // 这里可以添加其他Swing组件到JFrame中
        // ...
    }
    public static void main(String[] args) {
        // 在事件调度线程中创建和显示窗口
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                GameFrame frame = new GameFrame();
            }
        });
    }


}
