import java.awt.*;

public class ChessBoard {
    public ChessPiece[][] MyPieces = new ChessPiece[10][9];//创建一个棋子类型的二维数组，棋盘有10行9列，就是说有90个点可以放棋子
    public Point p1 = null;
    public Point p2 = null;


    public ChessBoard() {//棋盘类的构造方法
        int i;
        for (i = 0; i < 10; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.MyPieces[i][j] = null;
            }
        }//棋盘为空

        this.MyPieces[0][0] = new ChessPiece(1);//黑车
        this.MyPieces[0][1] = new ChessPiece(2);//黑马
        this.MyPieces[0][2] = new ChessPiece(5);//黑象
        this.MyPieces[0][3] = new ChessPiece(4);//黑士
        this.MyPieces[0][4] = new ChessPiece(0);//黑将
        this.MyPieces[0][5] = new ChessPiece(4);//黑士
        this.MyPieces[0][6] = new ChessPiece(5);//黑象
        this.MyPieces[0][7] = new ChessPiece(2);//黑马
        this.MyPieces[0][8] = new ChessPiece(1);//黑车

        for (i = 0; i < 9; i += 2) {
            this.MyPieces[3][i] = new ChessPiece(6);//黑卒
        }
        //下面是每个位置要放置的棋子
        this.MyPieces[2][1] = new ChessPiece(3);//黑炮
        this.MyPieces[2][7] = new ChessPiece(3);//黑炮
        this.MyPieces[9][0] = new ChessPiece(8);//红车
        this.MyPieces[9][1] = new ChessPiece(9);//红马
        this.MyPieces[9][2] = new ChessPiece(13);//红相
        this.MyPieces[9][3] = new ChessPiece(11);//红士
        this.MyPieces[9][4] = new ChessPiece(12);//红帅
        this.MyPieces[9][5] = new ChessPiece(11);//红士
        this.MyPieces[9][6] = new ChessPiece(13);//红相
        this.MyPieces[9][7] = new ChessPiece(9);//红马
        this.MyPieces[9][8] = new ChessPiece(8);//红车

        for (i = 0; i < 9; i += 2) {
            this.MyPieces[6][i] = new ChessPiece(7);//红兵
        }

        this.MyPieces[7][1] = new ChessPiece(10);//红炮
        this.MyPieces[7][7] = new ChessPiece(10);//红炮
    }

    public boolean PieceMove(Point src, Point des) {
        if (this.MyPieces[src.y][src.x] == null)
        {
            return false;//目前位置没有棋子
        }
        else if (src.x == des.x && des.y == src.y)
        {
            return false;
        }
        else
        {
            switch (this.MyPieces[src.y][src.x].name)
            {
                case "兵":
                    if (Math.abs(src.y - des.y) >= 2 || Math.abs(src.x - des.x) >= 2) {
                        return false;
                    } else {
                        if (des.y < src.y)//兵卒永远不后退
                        {
                            if (des.y < 0) {
                                return false;
                            } else {
                                if (des.x != src.x) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            }
                        } else if (des.y == src.y)//平兵
                        {
                            if (des.x < 0 || des.x > 8) {
                                return false;
                            } else {
                                if (src.y < 5 && src.y >= 0) {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        } else {
                            return false;
                        }
                    }
                case "炮":
                    if (src.x != des.x && src.y != des.y) {
                        return false;
                    } else if (src.x == des.x) {
                        int i;
                        int n = 0;
                        if (src.y < des.y) {
                            for (i = src.y + 1; i < des.y; i++) {
                                if (this.MyPieces[i][src.x] != null) {
                                    n++;
                                }
                            }
                            if (n >= 2) {
                                return false;
                            } else if (n == 1) {
                                if (this.MyPieces[des.y][des.x] != null) {
                                    if (this.MyPieces[des.y][des.x].tag != this.MyPieces[src.y][src.x].tag) {
                                        this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                        this.MyPieces[src.y][src.x] = null;
                                        return true;
                                    } else {
                                        return false;
                                    }
                                } else {
                                    return false;
                                }
                            } else {
                                if (this.MyPieces[des.y][des.x] == null) {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        } else {
                            for (i = src.y - 1; i > des.y; i--) {
                                if (this.MyPieces[i][src.x] != null) {
                                    n++;
                                }
                            }
                            if (n >= 2) {
                                return false;
                            } else if (n == 1) {
                                if (this.MyPieces[des.y][des.x] != null) {
                                    if (this.MyPieces[des.y][des.x].tag != this.MyPieces[src.y][src.x].tag) {
                                        this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                        this.MyPieces[src.y][src.x] = null;
                                        return true;
                                    } else {
                                        return false;
                                    }
                                } else {
                                    return false;
                                }
                            } else {
                                if (this.MyPieces[des.y][des.x] == null) {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                } else {
                                    return false;
                                }
                            }

                        }


                    } else if (src.y == des.y) {
                        int i;
                        int n = 0;
                        if (src.x != des.x) {
                            if (src.x < des.x) {
                                for (i = src.x + 1; i < des.x; i++) {
                                    if (this.MyPieces[src.y][i] != null) {
                                        n++;
                                    }
                                }
                            } else {
                                for (i = src.x - 1; i > des.x; i--) {
                                    if (this.MyPieces[src.y][i] != null) {
                                        n++;
                                    }
                                }
                            }

                            if (n == 0) {
                                if (this.MyPieces[des.y][des.x] != null) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else if (n == 1) {
                                if (this.MyPieces[src.y][src.x].tag == this.MyPieces[des.y][des.x].tag) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else {
                                return false;
                            }
                        }
                    }
                case "车":
                    if (src.x != des.x && src.y != des.y) {
                        return false;
                    } else {
                        int i;
                        int n = 0;
                        if (src.x == des.x) {
                            if (src.y < des.y) {
                                for (i = src.y + 1; i < des.y; i++) {
                                    if (this.MyPieces[i][src.x] != null) {
                                        n++;
                                    }
                                }
                            } else {
                                for (i = des.y + 1; i < src.y; i++) {
                                    if (this.MyPieces[i][src.x] != null) {
                                        n++;
                                    }
                                }
                            }

                            if (n == 0) {
                                if (this.MyPieces[des.y][des.x] != null) {
                                    if (this.MyPieces[des.y][des.x].tag == this.MyPieces[src.y][src.x].tag) {
                                        return false;
                                    } else {
                                        this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                        this.MyPieces[src.y][src.x] = null;
                                        return true;
                                    }
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else {
                                return false;
                            }
                        } else {
                            if (src.x < des.x) {
                                for (i = src.x + 1; i < des.x; i++) {
                                    if (this.MyPieces[src.y][i] != null) {
                                        n++;
                                    }
                                }
                            } else {
                                for (i = des.x + 1; i < src.x; i++) {
                                    if (this.MyPieces[src.y][i] != null) {
                                        n++;
                                    }
                                }
                            }

                            if (n == 0) {
                                if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == this.MyPieces[src.y][src.x].tag) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else {
                                return false;
                            }
                        }
                    }
                case "马":
                    if (Math.abs(des.y - src.y) * Math.abs(des.y - src.y) + Math.abs(des.x - src.x) * Math.abs(des.x - src.x) != 5) {
                        return false;
                    } else {
                        if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == this.MyPieces[src.y][src.x].tag) {
                            return false;
                        } else {
                            if (src.x + 2 == des.x) {
                                if (this.MyPieces[src.y][src.x + 1] != null) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else if (src.x - 2 == des.x) {
                                if (this.MyPieces[src.y][src.x - 1] != null) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else if (src.y + 2 == des.y) {
                                if (this.MyPieces[src.y + 1][src.x] != null) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else if (src.y - 2 == des.y) {
                                if (this.MyPieces[src.y - 1][src.x] != null) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            } else {
                                return false;
                            }
                        }
                    }
                case "相":
                    if (des.y <= 4) {
                        return false;
                    } else if ((des.y - src.y) * (des.y - src.y) + (des.x - src.x) * (des.x - src.x) != 8) {
                        return false;
                    } else {
                        if (this.MyPieces[(des.y + src.y) / 2][(des.x + src.x) / 2] != null) {
                            return false;
                        } else if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == this.MyPieces[src.y][src.x].tag) {
                            return false;
                        } else {
                            this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                            this.MyPieces[src.y][src.x] = null;
                            return true;
                        }
                    }
                case "象":
                    if(des.y>4)
                    {
                        return false;
                    }
                    else if((des.y - src.y) * (des.y - src.y) + (des.x - src.x) * (des.x - src.x) != 8)
                    {
                        return false;
                    }
                    else
                    {
                        if(this.MyPieces[(des.y + src.y) / 2][(des.x + src.x) / 2] != null)
                        {
                            return false;
                        }
                        else if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == this.MyPieces[src.y][src.x].tag) {
                            return false;
                        } else {
                            this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                            this.MyPieces[src.y][src.x] = null;
                            return true;
                        }
                    }

                case "士":
                    if (des.x < 3 || des.x > 5) {
                        return false;
                    } else if ((des.y - src.y) * (des.y - src.y) + (des.x - src.x) * (des.x - src.x) != 2) {
                        return false;
                    } else if ((this.MyPieces[src.y][src.x].tag == 1 && des.y > 2) || (this.MyPieces[src.y][src.x].tag == 0 && des.y < 7)) {
                        return false;
                    } else if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == this.MyPieces[src.y][src.x].tag) {
                        return false;
                    } else {
                        this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                        this.MyPieces[src.y][src.x] = null;
                        return true;
                    }
                case "帅":
                    if (des.x < 3 || des.x > 5 || des.y < 7) {
                        return false;
                    } else {
                        if ((des.y - src.y) * (des.y - src.y) + (des.x - src.x) * (des.x - src.x) != 1) {
                            return false;
                        } else {
                            if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == 0) {
                                return false;
                            } else {
                                this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                this.MyPieces[src.y][src.x] = null;
                                return true;
                            }
                        }
                    }
                case "将":
                    if (des.x < 3 || des.x > 5 || des.y > 2) {
                        return false;
                    } else {
                        if ((des.y - src.y) * (des.y - src.y) + (des.x - src.x) * (des.x - src.x) != 1) {
                            return false;
                        } else {
                            if (this.MyPieces[des.y][des.x] != null && this.MyPieces[des.y][des.x].tag == 1) {
                                return false;
                            } else {
                                this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                this.MyPieces[src.y][src.x] = null;
                                return true;
                            }
                        }
                    }
                case "卒":
                    if (Math.abs(src.y - des.y) >= 2 || Math.abs(src.x - des.x) >= 2) {
                        return false;
                    } else {
                        if (des.y >src.y)//兵卒永远不后退
                        {
                            if (des.y < 0) {
                                return false;
                            } else {
                                if (des.x != src.x) {
                                    return false;
                                } else {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                }
                            }
                        } else if (des.y == src.y)//平卒
                        {
                            if (des.x < 0 || des.x > 8) {
                                return false;
                            } else {
                                if (src.y >= 5 && src.y <= 9) {
                                    this.MyPieces[des.y][des.x] = this.MyPieces[src.y][src.x];
                                    this.MyPieces[src.y][src.x] = null;
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        } else {
                            return false;
                        }
                    }
            }
        }
        return false;
    }
}


