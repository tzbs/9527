import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.util.logging.Logger;

public class ChessBoardPanel extends JPanel//创建一个棋盘容器ChessBoardPanel类
{
    private static final Logger logger = Logger.getLogger("ChessBoardPanel.class");
    private Image chessboard;//定义一个Image类型的变量chessboard，表示棋盘
    public ChessBoardPanel()//无参构造方法
    {
        chessboard=Toolkit.getDefaultToolkit().getImage(ChessBoardPanel.class.getResource("/Image/chessboard.png"));//给chessboard赋初值
        this.setBounds(0,0,560,630);//容器的大小为560*630
    }
    @Override
    protected void paintComponent(Graphics g)
    {
        logger.info("Entering paintComponent");
        super.paintComponent(g);
        if (chessboard != null) {
            g.drawImage(chessboard,0,0,560,630,this);//把棋盘图像绘制到容器ChessBoardPanel上
        }

        int xx = 15;
        int yy = 15;
        int pp = 60;
        for(int i = 0; i < 10; ++i) {
            for(int j = 0; j < 9; ++j) {
                if (GameFrame.MyBoarder.MyPieces[i][j] != null) {
                    g.drawImage(GameFrame.MyBoarder.MyPieces[i][j].Icon, xx + j * pp, yy + i * pp, GameFrame.MyBoarder.MyPieces[i][j].Icon.getWidth((ImageObserver)null), GameFrame.MyBoarder.MyPieces[i][j].Icon.getHeight((ImageObserver)null), this);
                }
            }
        }

        if (GameFrame.MyBoarder.p1 != null) {
            g.drawImage(Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/kuang.png")), 15 + GameFrame.MyBoarder.p1.x * pp, 15 + GameFrame.MyBoarder.p1.y * pp, Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/kuang.png")).getWidth((ImageObserver)null), Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/kuang.png")).getHeight((ImageObserver)null), this);
        }

        if (GameFrame.MyBoarder.p2 != null) {
            g.drawImage(Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/kuang.png")), 15 + GameFrame.MyBoarder.p2.x * pp, 15 + GameFrame.MyBoarder.p2.y * pp, Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/kuang.png")).getWidth((ImageObserver)null), Toolkit.getDefaultToolkit().getImage(GameFrame.class.getResource("/Image/kuang.png")).getHeight((ImageObserver)null), this);

        }
    }

}
