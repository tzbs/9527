import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.logging.Logger;


public class ChessPieceClick extends MouseAdapter {
    private static final Logger logger = Logger.getLogger("ChessPieceClick.class");
    public int i=1;
    public ChessPieceClick() {
    }
    @Override
    public void mouseClicked(MouseEvent arg0)
    {
        logger.info("Entering mouseClicked");
        System.out.println("这是第"+i+"次调用该函数");
        i++;
        int x = arg0.getX();
        int y = arg0.getY();
        x = x / 60;
        y = y / 60;
        System.out.println(x + "," + y);
        if((!(x>=0&&x<=8))||(!(y>=0&&y<=9)))
        {
            GameFrame.MyBoarder.p1 = null;
            return;
        }
        if(GameFrame.temp==1)
        {
            GameFrame.MyBoarder.p1 = null;
            GameFrame.MyBoarder.p2 = null;
            if(GameFrame.doplayer==1)
            {
                GameFrame.doplayer=0;
            }
            else
            {
                GameFrame.doplayer=1;
            }
        }
        GameFrame.temp=0;
        if (GameFrame.MyBoarder.p1 == null) {//第一次点击棋盘，在点击处出现一个框
            GameFrame.MyBoarder.p1 = new Point(x, y);
        }
        else
        {
            if (GameFrame.MyBoarder.MyPieces[GameFrame.MyBoarder.p1.y][GameFrame.MyBoarder.p1.x] == null) {
                GameFrame.MyBoarder.p1 = new Point(x, y);
            }
            else
            {
                if (GameFrame.MyBoarder.MyPieces[GameFrame.MyBoarder.p1.y][GameFrame.MyBoarder.p1.x].tag != GameFrame.doplayer) {
                    GameFrame.MyBoarder.p1 = new Point(x, y);
                }
                else
                {
                    if (GameFrame.MyBoarder.MyPieces[y][x] == null) {
                        System.out.println("开始选的自己棋子，又点了个空位置");
                        GameFrame.MyBoarder.p2 = new Point(x, y);
                        if(GameFrame.MyBoarder.PieceMove(GameFrame.MyBoarder.p1,GameFrame.MyBoarder.p2))
                        {
                            System.out.println("棋子可以移动");
                            GameFrame.temp=1;
                        }
                        else
                        {
                            GameFrame.MyBoarder.p1 = new Point(x, y);
                            GameFrame.MyBoarder.p2 = null;
                        }
                    }
                    else
                    {
                        if (GameFrame.MyBoarder.MyPieces[y][x].tag == GameFrame.doplayer) {
                            System.out.println("开始选的自己的棋子，之后又选了自己的棋子,走棋无效");
                            GameFrame.MyBoarder.p1 = new Point(x, y);
                        }
                        else
                        {
                            System.out.println("开始选的自己的棋子，之后又选了对方的棋子");
                            GameFrame.MyBoarder.p2 = new Point(x, y);
                              if(GameFrame.MyBoarder.PieceMove(GameFrame.MyBoarder.p1,GameFrame.MyBoarder.p2))
                              {
                                  System.out.println("棋子可以移动");
                                  GameFrame.temp=1;
                              }
                              else
                              {
                                  GameFrame.MyBoarder.p1 = new Point(x, y);
                                  GameFrame.MyBoarder.p2 = null;
                              }

                        }
                    }
                }
            }
        }
        ((ChessBoardPanel) arg0.getSource()).repaint();
        //((ChessBoardPanel) arg0.getSource()).paintImmediately(0, 0, ((ChessBoardPanel) arg0.getSource()).getWidth(), ((ChessBoardPanel) arg0.getSource()).getHeight());
        //logger.info("Entering mouseClicked");
    }
}
