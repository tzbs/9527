import java.awt.*;

public class ChessPiece //定义一个棋子类
{
    public String name;//棋子的名称，用字符串表示
    public int id;//给棋子设定一个编号
    public Image Icon;//棋子的外貌
    public int tag;//红方棋子还是黑方棋子，用1表示黑方，用0表示红方

    public ChessPiece(int Id) {//定义一个带参的构造方法，给棋子对象初始化
        this.id = Id;
        String FileName = null;//定义一个局部变量，这是为了给棋子的外貌属性赋值，可查看图片的命名方式
        if (this.id == 0) {
            this.name = new String("将");
            FileName = new String("black-jiang");
            this.tag=1;
        } else if (this.id == 1) {
            this.name = new String("车");
            FileName = new String("black-ju");
            this.tag=1;
        } else if (this.id == 2) {
            this.name = new String("马");
            FileName = new String("black-ma");
            this.tag=1;
        } else if (this.id == 3) {
            this.name = new String("炮");
            FileName = new String("black-pao");
            this.tag=1;
        } else if (this.id == 4) {
            this.name = new String("士");
            FileName = new String("black-shi");
            this.tag=1;
        } else if (this.id == 5) {
            this.name = new String("象");
            FileName = new String("black-xiang");
            this.tag=1;
        } else if (this.id == 6) {
            this.name = new String("卒");
            FileName = new String("black-zu");
            this.tag=1;
        } else if (this.id == 7) {
            this.name = new String("兵");
            FileName = new String("red-bing");
            this.tag=0;
        } else if (this.id == 8) {
            this.name = new String("车");
            FileName = new String("red-ju");
            this.tag=0;
        } else if (this.id == 9) {
            this.name = new String("马");
            FileName = new String("red-ma");
            this.tag=0;
        } else if (this.id == 10) {
            this.name = new String("炮");
            FileName = new String("red-pao");
            this.tag=0;
        } else if (this.id == 11) {
            this.name = new String("士");
            FileName = new String("red-shi");
            this.tag=0;
        } else if (this.id == 12) {
            this.name = new String("帅");
            FileName = new String("red-shuai");
            this.tag=0;
        } else if (this.id == 13) {
            this.name = new String("相");
            FileName = new String("red-xiang");
            this.tag=0;
        }

        this.Icon = Toolkit.getDefaultToolkit().getImage(ChessPiece.class.getResource("/Image/" + FileName + ".png"));

    }

}
